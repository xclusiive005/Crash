
import Dashboard from "@/components/crash/Dashboard";

export default function Home() {
  return <Dashboard />;
}
